package com.capgemini.pizzaorder.ui;


import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.capgemini.pizzaorder.bean.Customer;
import com.capgemini.pizzaorder.dao.*;
import java.sql.*;

public class Client {
	
	
	public static void main(String[] args) throws SQLException {
		 String name1;
		 String addr;
		 String x;
		 int id;
		int y,top;
		 Scanner sc=new Scanner(System.in);
		Customer d=new Customer();//customer bean
		PizzaOderDAO d1=new PizzaOderDAO();
		System.out.println("1.place order \n 2.diplay order \n 3.exit \n enter option");
		int opt=sc.nextInt();
		switch(opt)
		{
		case 1:System.out.println("enter  your name");
				name1=sc.next();
				d.setName(name1);
				System.out.println("enter address");
				addr=sc.next();
				d.setAddr(addr);
				System.out.println("enter phone num");
				x=sc.next();
				int s=validate(x);
					if(s==1)
					{
				d.setPhoneNumber(x);
					}
					else {
						System.out.println("Invalid Number");
						return;
					}
				System.out.println("1.Capsicum\n 2.mushroom\n 3.jalapeno \n 4.panner \n enter choice");
				y=sc.nextInt();
				top=toppings(y);
				d1.insert(d,top);
				d1.insert1(d,top);
				break;
		case 2:System.out.println("enter order-id");
				id=sc.nextInt();
				d1.display(id);
				
				break;
		case 3:System.out.println("exiting from the application");
				break;
		default:System.out.println("enter valid option");
			
				
				
		}
		

	}

 private static int toppings(int y) {
	if(y==1)
		return 30;
	else if(y==2)
		return 50;
	else if(y==3)
	return 70;
	else if(y==4)
		return 85;
	else
	return 0;
	
		
	}

static int  validate(String x) {
		// TODO Auto-generated method stub
	 if (isValid(x))  
	 {
         System.out.println("Valid Number");   
         return 1;
	 }
     else 
     {
        // System.out.println("Invalid Number");  
         return 0;

     }
	
	}
 public static boolean isValid(String s) 
 { 
     Pattern p = Pattern.compile("(0/91)?[7-9][0-9]{9}"); 
     Matcher m = p.matcher(s); 
     return (m.find() && m.group().equals(s)); 
 } 

}
