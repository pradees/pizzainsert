package com.capgemini.pizzaorder.dao;


import java.sql.Connection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.pizzaorder.bean.Customer;
import com.cg.pizza.util.CommConnection;

public class PizzaOderDAO {
	Connection cn;
	//PreparedStatement pst;
	//PreparedStatement pst1;
	PreparedStatement pst;
	PreparedStatement pst1;

	float price,tax,total;
	ResultSet rs =null;
	//static String sql4="select customerseq.nextval from dual";
	//static String sql3="select customerseq.currval from dual";
public void insert(Customer d,int i) {
		try
		{
			cn=CommConnection.getCon();
			
			String sql="insert into cust_details values(customerseq.nextval,?,?,?)";//worked
		pst=cn.prepareStatement(sql);
		 
			
			//pst.setString(1, "customerseq.nextval");
			pst.setString(1,d.getName());
			pst.setString(2, d.getAddr());
			pst.setString(3,d.getPhoneNumber());
			pst.executeUpdate();
			
			System.out.println("inserted into cust_details");
			//insert1(d);
			//System.out.println("sdfhj");
			/*String sql1="insert into pizz_entry(orderid,custid,totalprice,orderdate) values(pizzaseq.nextval,(select custid from cust_details where custname=?),?,sysdate)";
			//(select custid from cust_details where custname=?)
			pst1=cn.prepareStatement(sql1);
			
			pst1.setString(1,d.getName());
			pst1.setString(2,"price");
			pst1.executeUpdate();
			System.out.println("inserted into pizz_entry");
		
			//int k;
			//String phn=d.getPhoneNumber();
			//pst.setString(3,phn);
			//pst=cn.prepareStatement("insert into pizz_entry values(pizzaseq.nextval,?,?,?)");*/
		
			
			
			
			
			
		
		}catch(Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		finally
		{
			try {
				pst.close();
				cn.close();
				System.out.println("closed connection");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
			}

	public void insert1(Customer d,int i) throws SQLException {
		// TODO Auto-generated method stub
		cn=CommConnection.getCon();
		String sql3="select customerseq.nextval from dual";
		//String sql3="SELECT last_number FROM user_sequences WHERE sequence_name = 'customerseq'";
		//String sql1="insert into pizz_entry(orderid,custid,totalprice,orderdate) values(pizzaseq.nextval,(select custid from cust_details where custname=?),?,sysdate)";
		//(select custid from cust_details where custname=?)
		String sql1="insert into pizz_entry values(pizzaseq.nextval,?,?,SYSDATE)";
		//String sql1="insert into pizz_entry(orderid,custid,TOTALPRICE,ORDERDATE) values(pizzaseq.nextval, (select last_number from user_sequences where sequence_name='customerseq'),?,SYSDATE)";
		//PreparedStatement pst4 = cn.prepareStatement(PizzaOderDAO.sql4);
		PreparedStatement pst3 = cn.prepareStatement(sql3);
		rs=pst3.executeQuery();
		int id = 0;
		while(rs.next()) {
		 id=rs.getInt(1);
		System.out.println(id);}
		try {
			total=350+i;
			tax=(float) (0.04*total);
			price=total+tax;
			System.out.println(price);
			pst1=cn.prepareStatement(sql1);
			pst1.setInt(1,id);
			pst1.setFloat(2,price);
			pst1.executeUpdate();
			System.out.println("your id:"+id);
			System.out.println("inserted into pizz_entry");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			
			try {
				pst1.close();
				cn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		}
		
	

	public void display(int id) {
		try
		{
			cn=CommConnection.getCon();
			//String sql="select *from pizz_entry";
		Statement stmt=cn.createStatement();
			rs=stmt.executeQuery("select *from pizz_entry where custid="+id);
		
		while(rs.next())	
		{
			int orderid=rs.getInt(1);
			int custid=rs.getInt(2);
			float price=rs.getFloat(3);
			String date=rs.getString(4);
		System.out.println(orderid+"  "+ custid+" "+price+" "+date);
		}		
		}catch(Exception e)
		{
			//System.out.println(e);
			e.printStackTrace();
		}
		
	}

}
